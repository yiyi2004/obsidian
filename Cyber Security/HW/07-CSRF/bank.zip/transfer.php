<?php 
	include("config.php");
	if(isset($_COOKIE["userid1"]) && isset($_COOKIE["pass1"]))
	{
		$TOID=$_GET['nameid'];
		$TOMONEY= $_GET['balance'];
		include("conn/conn.php");
		$sql=$db->query("select * from account where userid='".$TOID."'");
		
		$sqlres = $sql->fetch();
		if($sqlres['userid'] != $TOID)
		{
			echo "<script language=\"javascript\">";
			echo "alert('用户名或密码错误!')";
			echo "return(true)";
				echo "location.href=\"default.php\"";
				echo "</script>";
		}
		$balance_new = $TOMONEY + $sqlres['balance'];
		$sql=$db->exec("update account set balance='".$balance_new."' where userid='".$TOID."'");
		$sql=$db->query("select * from account where userid='".$_COOKIE['userid1']."'");
		$sqlres = $sql->fetch();
		$balance_new = $sqlres['balance']- $TOMONEY;
		$sql=$db->exec("update account set balance='".$balance_new."' where userid='".$_COOKIE['userid1']."'");
			
			echo "<script language=\"javascript\">";
				echo "location.href=\"default.php\"";
				echo "</script>";
				
	}

?>