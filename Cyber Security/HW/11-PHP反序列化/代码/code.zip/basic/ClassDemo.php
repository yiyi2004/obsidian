<?php

/**
 * Class ClassDemo
 * 一个简单的类的演示
 */
class ClassDemo
{
    public $var = "PHP is the best language in the world\n";

    public function echoString(){
        echo $this->var;
    }
}
// 创建一个新的对象
$obj = new ClassDemo();
// 调用该类的方法
$obj->echoString();