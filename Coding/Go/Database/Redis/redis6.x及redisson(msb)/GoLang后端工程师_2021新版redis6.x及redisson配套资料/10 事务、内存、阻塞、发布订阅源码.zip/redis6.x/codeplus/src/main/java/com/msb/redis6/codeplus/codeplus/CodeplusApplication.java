package com.msb.redis6.codeplus.codeplus;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@MapperScan
@EnableCaching
public class CodeplusApplication {

    public static void main(String[] args) {
        SpringApplication.run(CodeplusApplication.class, args);
    }

}
