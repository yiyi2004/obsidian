<?php

/**
 * Class MyClass
 * Magic函数演示
 */
class MyClass
{
    public $var = "hello wuya\n";

    public function echoString(){
        echo $this->var;
    }

    public function __construct(){
        echo "__construct\n";
    }

    public function __destruct(){
        echo "__destruct\n";
    }

    public function __toString(){
        return "__toString\n";
    }
}

// 创建一个新的对象，__construct被调用
$obj = new MyClass();
// 调用该类的方法
$obj->echoString();
// 以字符形式输出，__toString方法被调用
echo $obj;
// php脚本要结束时，__destruct会被调用