package com.wuya;

public class LinuxTouch {
    public LinuxTouch(){
        try{
            Runtime.getRuntime().exec("touch /tmp/fast-success.txt");
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void main(String[] argv){
        LinuxTouch e = new LinuxTouch();
    }
}
