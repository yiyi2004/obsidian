
SELECT VERSION();



SELECT *
FROM itemtab;

DROP TABLE itemtab;

CREATE TABLE itemtab
(
    id     INT PRIMARY KEY auto_increment,
    itemid INT NOT NULL,
    nums   INT

);

CREATE TABLE itemtab
(
    id     INT PRIMARY KEY auto_increment,
    itemid INT NOT NULL,
    nums   INT,
    INDEX (itemid)

);

CREATE TABLE itemtab
(
    id     INT NOT NULL  auto_increment,
    itemid INT PRIMARY KEY,
    nums   INT,
    INDEX (id)
);

delete
from itemtab
where 1 = 1;
insert into itemtab (itemid, nums)
values (11, 22);


show variables like '%max_connection%';
set global max_connections = 1000;
show status like 'Threads%';