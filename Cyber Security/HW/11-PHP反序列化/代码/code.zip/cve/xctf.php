<?php

class xctf{
    public $flag = '111';
}
$a = new xctf();
echo serialize($a);
// O:4:"xctf":2:{s:4:"flag";s:3:"111";}