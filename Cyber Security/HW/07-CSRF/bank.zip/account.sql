/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50728
Source Host           : localhost:3306
Source Database       : bank

Target Server Type    : MYSQL
Target Server Version : 50728
File Encoding         : 65001

Date: 2021-05-04 16:27:03
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `balance` int(11) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES ('1100', '无涯', '9000', '男', '123456');
INSERT INTO `account` VALUES ('1101', '麻辣', '11000', '女', '000000');
INSERT INTO `account` VALUES ('1102', '小刘', '0', '女', '000000');
