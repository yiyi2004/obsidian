package com.msb.redis6.codeplus.codeplus.controller;

import com.msb.redis6.codeplus.codeplus.service.CacheService;
import com.msb.redis6.codeplus.codeplus.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author: 马士兵教育_周志垒
 */

/**
 * 多级缓存，加本地缓存，是一个全局手段
 * 单体服务可以加本地缓存
 * 不对，就像单机锁一样，有本地的前置
 */

@RestController
public class ConcurrentController {

    @Autowired
    ItemService itemService;

    @Autowired
    CacheService cacheService;

    @RequestMapping(value = "/mysql", method = RequestMethod.GET)
    public String concurrentByMysql(Integer itemID) {
        /**
         * 扣减库存，不用任何技术的情况下
         *  update  where 就可以了
         *  不需要分布式锁的
         *
         *         update itemtab
         *         set nums=nums - 1
         *         where nums > 0
         *           and itemid = #{itemID}  //where 中要有索引，规避全表扫描
         *
         *  ：TPS  4000
         *  缺点：每一个请求都会到达数据去验证是否还有库存
         *  大量的无效请求施加给了mysql
         *
         *  补充：已经出现了秒级，十秒级
         *  很简单的思路:阉割法
         *  思考，追踪是自己的代码逻辑问题，还是你有调用了其他接口
         *
         *  优化：减少mysql的无效请求，毕竟数据库是项目的命根子
         *
         *  首先：AKF划分 ，原地，隔离性，扩展性能
         *
         *  向前考虑，加前置过滤，最明显的减少无效
         *
         */


        itemService.decrNumByWhere(itemID);

        return "";
    }


    @RequestMapping(value = "/redis", method = RequestMethod.GET)
    public String concurrentByRedis(Integer itemID) {
        /**
         * 思路：请求先到达redis
         *  受很多的影响，其实不用分布式锁，性能更低
         *  1）redis的排他性【锁，session，静态的，是标志】
         *  2）使用redis的过滤特性【串行，+/-，set，list queue，。。动态】
         *
         *  数据库和redis都初始化item的num
         *  请求通过对redis的num的递减，到达0的时候，不再向数据库发出请求
         *
         *   注意,只要加了redis，的确有性能的提升
         *   TPS：7000
         *
         *   的确拦住了mysql的无效请求
         *   性能还如何提升，核心点是cacheService.decrNum(itemID);
         *
         *   因为，redis的请求你要去分析，你是不是造成了无效请求
         *
         *   作为开发者，你平时关注的是自己的crud
         *   127.0.0.1:6379> get 1111
         *   "-198"
         *   127.0.0.1:6379> get 1112
         *   "-187"
         *   127.0.0.1:6379> get 1113
         *   "-199"
         */
        boolean skip = cacheService.decrNum(itemID);

        if(skip){
            //最终，还得靠数据库保证数据
            itemService.decrNum(itemID);
        }

        return "";
    }

    /**
     * 线程池隔离
     * 单一商品并不是真正的并行，而是串行的
     * 介入线程池资源隔离的方式：
     * 单线程的线程池
     *
     */
    @RequestMapping(value = "/thread", method = RequestMethod.GET)
    public String concurrentByThread(Integer itemID) {
        /**
         * 那么聪明的小伙伴说了：
         * 性能没有提升
         * 无论你做不做item的分段
         * 这里的singleES  他能保证一个item的请求是右一个thread有序处理的
         * 那么，当第一个请求发现自己的返回值是负数的时候，自己提交的事务，
         * 便于后续多有提交不会出发重复事务提交了
         *
         * 优势，最明显的是减少redis的无效请求
         *
         * 不用这个方案
         * 出现-1 -2  并发的会有去提交redis事务  setbit  修正
         * 如果用了这个方案
         * 单线程有序性，会让redis事务O(1)
         *
         *
         *
         * singleES  把并转串
         * ThreadLocal  链式处理可以本地化掌控资源
         *
         * 根据id存threadLocal啊：
         * 这就是线程间通信的问题了
         * tomcat  T1   T2    T3
         * 从IO中得到的request是一个ID ？
         * 准备一个singleES@T4
         * T1~3 @ call  ->  singleES@T4.submit(call)
         *
         */

        /**
         * cacheService.decrNumByThread(itemID);
         * tomcat的当前线程会阻塞等待future.get()
         * 逻辑被异步的发送到singleES中执行
         * 所以，对于redis的使用是同一个商品会再一个singleES中串行
         *
         * 再单一商品的时候  TPS 1600
         * 因为 商品就一个，所以，只用了一个singleES线程池，排队执行
         *
         * 当商品很多的时候，才能散开，发挥性能，TPS 6000
         * 思路：有序加分段
         *
         * itemID  num=100
         * 分成2端
         * itemID_1  50
         * itemID_2  50
         *
         */
        boolean skip = cacheService.decrNumByThread(itemID);
        if(skip){
            itemService.decrNum(itemID);
        }

        return "";
    }

    @RequestMapping(value = "/db", method = RequestMethod.GET)
    public String concurrentByDB(Integer itemID) {
        itemService.decrNum(itemID);
        itemService.delByItemID(999);
        itemService.insertVal(999, 999);
        itemService.updateByItemID(999, 222);
        itemService.selectA();
        return "";

    }


    @RequestMapping(value = "resetData", method = RequestMethod.GET)
    public String restData(Integer minID, Integer maxID, Integer num) {
        itemService.delAll();
        for (int i = minID; i < maxID; i++) {
            cacheService.resetData(i, num);
            itemService.insertVal(i, num);
        }
        return "";
    }
}
