package com.msb.redis6.codeplus.codeplus.mapper;

import com.msb.redis6.codeplus.codeplus.entity.ItemInfo;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author: 马士兵教育_周志垒
 */

@Repository
public interface ItemtabMapper {
    /*


    file: com/sean/publession/nonelock/mapper/ItemtabMapper.xml
    <?xml version="1.0" encoding="UTF-8" ?>
    <!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
                "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
    <mapper namespace="com.sean.publession.nonelock.mapper.ItemtabMapper">
        <select id="selectAll" resultType="com.sean.publession.nonelock.entity.ItemTab">
        select * from itemtab
        </select>
        <update id="decrNums"  >
        update itemtab set nums=nums-1  where nums>0 and itemid=#{itemID}
        </update>
    </mapper>

    file: application.yml
    mybatis:
    mapper-locations: classpath:mapper/*.xml

     */


    //    @Select (  "select * from itemtab")
    List<ItemInfo> selectAll();

    //    @Update("update itemtab set nums=nums-1  where nums>0 and itemid=#{itemID}")
    Integer decrNumsDB(Integer itemID);

    Integer decrNumsRedis(Integer itemID);

    boolean resetData(Integer itemID, Integer num);

    void insertVal(Integer itemID, Integer num);

    void delByItemID(Integer itemID);

    void delAll();



}
