package com.wuya;

import java.io.*;

public class TestToFile {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Person obj= new Person("wuya", 666);
        String filePath = "D:/wuya.xxx";

        // 序列化
        ObjectOutputStream  outStream = new ObjectOutputStream(new FileOutputStream(filePath));
        outStream.writeObject(obj);

        // 反序列化
        ObjectInputStream  inStream = new ObjectInputStream(new FileInputStream(filePath));
        // readObject 方法
        Person readObject = (Person)inStream.readObject();
        System.out.println("反序列化后：name="+readObject.name +",age="+readObject.age);
    }

}
