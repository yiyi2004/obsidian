<?php

/**
 * Class JsonClass
 * JSON和XML序列化演示
 */
class JsonClass
{
    public $word = "hello wuya";

    public $prop = array('name' => 'wuya', 'age' => 31, 'motto' => 'Apple keep doctor');
}
$obj = new JsonClass();
// 转换对象为JSON字符串
$s = json_encode($obj);
// 转换对象为XML
$x = wddx_serialize_value($obj );
echo $s;
echo "\n";
echo $x;