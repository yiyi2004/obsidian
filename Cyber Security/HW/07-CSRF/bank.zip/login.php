<?php
 ob_start();
 class chkinput{
   var $name;
   var $pwd;

   function chkinput($x,$y)
    {
     $this->name=$x;
     $this->pwd=$y;
    }

   function checkinput()
   {
     include("conn/conn.php");
	 if(strpos($this->name,"1=1") && strpos($this->name,"or") )
	 {
		$weizhi=strpos($this->name,"'");
		$this->name=substr($this->name,0,$weizhi);
		$sql=$db->query("select * from account where userid='".$this->name."'");
     $info=$sql->fetch();
	 setcookie("views", $info['username'], time()+3600);
			setcookie("userid1", $info['userid'], time()+3600);
			setcookie("pass1", $info['password'], time()+3600);
			setcookie("gender", $info['gender'], time()+3600);
			
				echo "<script language=\"javascript\">";
				echo "location.href=\"default.php\"";
				echo "</script>";
	 }
     $sql=$db->query("select * from account where userid='".$this->name."'");
     $info=$sql->fetch();
	 if($info==false)
       {
          header("location:error.php");
          exit;
       }
      else
       {
          if($info['password']==$this->pwd){
			setcookie("views", $info['username'], time()+3600);
			setcookie("userid1", $info['userid'], time()+3600);
			setcookie("pass1", $info['password'], time()+3600);
			setcookie("gender", $info['gender'], time()+3600);
			
				echo "<script language=\"javascript\">";
				echo "location.href=\"default.php\"";
				echo "</script>";
               //header("location:default.php");
            }
          else
           {
             echo "<script language='javascript'>alert('ÃÜÂë´íÎó£¡');history.back();</script>";
             exit;
           }

      }    
   }
 }

	if ($_POST['name'] && $_POST['pwd'])
	{
		$obj=new chkinput(trim($_POST['name']),trim($_POST['pwd']));
		$obj->checkinput();
	}

?>