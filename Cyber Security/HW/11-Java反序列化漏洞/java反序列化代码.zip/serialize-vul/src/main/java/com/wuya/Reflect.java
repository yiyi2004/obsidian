package com.wuya;

import java.io.*;

public class Reflect {
    public static void main(String[] args) throws IOException {
        test2();

    }

    public static void test1() throws IOException {
        Runtime.getRuntime().exec("calc");
    }

    public static void test2(){
        try {
            //初始化Runtime类
            Class clazz = Class.forName("java.lang.Runtime");
            // 调用Runtime类中的getRuntime方法得到Runtime类的对象
            Object rt = clazz.getMethod("getRuntime").invoke(clazz);
            //再次使用invoke调用Runtime类中的方法时，传递我们获得的对象，这样就可以调用
            clazz.getMethod("exec",String.class).invoke(rt,"calc");
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void test3(){
        // Runtime类没有继承Serializable接口
        try {
            //要序列化的数据
            Object runtime = Class.forName("java.lang.Runtime").getMethod("getRuntime", new Class[]{}).invoke(null);
            Object evil = Class.forName("java.lang.Runtime").getMethod("exec", String.class).invoke(runtime, "calc");

            //序列化
            FileOutputStream fileOutputStream = new FileOutputStream("serialize2.txt");
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(evil);
            objectOutputStream.close();

            //反序列化
            FileInputStream fileInputStream = new FileInputStream("serialize2.txt");
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            Object result = objectInputStream.readObject();
            objectInputStream.close();
            System.out.println(result);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
