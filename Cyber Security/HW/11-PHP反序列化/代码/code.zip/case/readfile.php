<?php


class readfile
{
//文件名
    public $filename = 'error.log';
    //当对象被作为一个字符串会读取这个文件
    public function __toString()
    {
        return file_get_contents($this->filename);
    }
}

class user
{
    //class data
    public $age = 0;
    public $name = '';
    //允许对象作为一个字符串输出上面的data
    public function __toString()
    {
        return 'user '.$this->name.' is '.$this->age.' years old.<br />';
    }
}

// 动态传入反序列化字符
$obj = unserialize($_GET['param']);
// __toString被调用
echo $obj;
?>