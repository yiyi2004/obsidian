INSERT INTO `test` (`user`, `password`) VALUES ('wuya', '123456');
INSERT INTO `test` (`user`, `password`) VALUES ('admin', 'admin');
