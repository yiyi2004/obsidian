<?php

/**
 * Class SerialType
 * 不同类型的序列化演示
 */
class SerialType{

    public $data;
    private $pass;
    const CONTRY = 'CHINA';

    public function __construct($data, $pass)
    {
        $this->data = $data;
        $this->pass = $pass;
    }
}
$number = 32;
$str = 'wuyayy';
$bool = false;
$null = NULL;
$arr = array('aa' => 1, 'bbbb' => 9);
$obj = new SerialType('somestr', true);

var_dump(serialize($number));
var_dump(serialize($str));
var_dump(serialize($bool));
var_dump(serialize($null));
var_dump(serialize($arr));
var_dump(serialize($obj));
var_dump(serialize(CONTRY));