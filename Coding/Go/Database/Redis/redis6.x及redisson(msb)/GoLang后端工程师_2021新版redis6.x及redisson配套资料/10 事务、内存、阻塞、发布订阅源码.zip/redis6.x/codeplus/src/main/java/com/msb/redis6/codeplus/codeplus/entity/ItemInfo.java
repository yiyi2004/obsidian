package com.msb.redis6.codeplus.codeplus.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author: 马士兵教育_周志垒
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ItemInfo {

    private int id;
    private int itemid;
    private int nums;
}
