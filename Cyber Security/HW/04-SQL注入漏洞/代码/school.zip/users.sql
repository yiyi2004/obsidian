INSERT INTO `users` (`id`, `name`, `password`) VALUES ('1', 'admin', '123456');
INSERT INTO `users` (`id`, `name`, `password`) VALUES ('2', 'abandon', '111111');
INSERT INTO `users` (`id`, `name`, `password`) VALUES ('3', 'zac', '000000');
