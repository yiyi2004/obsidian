package com.msb.redis6.codeplus.codeplus.service;


import com.msb.redis6.codeplus.codeplus.entity.ItemInfo;
import com.msb.redis6.codeplus.codeplus.mapper.ItemtabMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author: 马士兵教育_周志垒
 */

@Service
public class ItemService {


    @Autowired
    ItemtabMapper mapper;

    public List<ItemInfo> selectA() {
        return mapper.selectAll();
    }

    public boolean decrNumByWhere(Integer itemID) {
        return mapper.decrNumsDB(itemID) > 0;
    }
    public boolean decrNum(Integer itemID) {
        return mapper.decrNumsRedis(itemID) > 0;
    }

    public void insertVal(Integer itemID, Integer num) {
        mapper.insertVal(itemID, num);
    }

    public void delByItemID(Integer itemID) {
        mapper.delByItemID(itemID);
    }


    public void delAll() {
        mapper.delAll();

    }

    public void updateByItemID(int itemID, int num) {
        mapper.resetData(itemID, num);
    }
}
