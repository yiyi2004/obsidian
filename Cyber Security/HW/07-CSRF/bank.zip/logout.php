<?php
	//include("config.php");

	setcookie("view1", "", time()-3600);
	setcookie("userid1", "", time()-3600);
	setcookie("pass1", "", time()-3600);
	setcookie("gender", "", time()-3600);
	
	echo "<script language='javascript'>window.location.href='index.html';</script>";
?>  