<?php

include 'logfile.php';
$obj = new logfile();

$obj->filename = 'index.php';

// 序列化
echo serialize($obj) ;
