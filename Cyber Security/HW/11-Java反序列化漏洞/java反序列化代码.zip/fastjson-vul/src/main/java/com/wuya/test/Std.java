package com.wuya.test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;

public class Std {
    public static void main(String[] args) {
        User user = new User();
        user.setName("wuya");
        user.setAge(33);
        String s1 = JSON.toJSONString(user, SerializerFeature.WriteClassName);
        System.out.println(s1);

        User user2 = JSON.parseObject(s1,User.class);
        System.out.println(user2);
    }
}
