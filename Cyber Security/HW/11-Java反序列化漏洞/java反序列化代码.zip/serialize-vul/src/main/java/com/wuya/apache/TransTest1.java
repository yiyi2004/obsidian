package com.wuya.apache;

import org.apache.commons.collections.functors.InvokerTransformer;

/**
 * InvokerTransformer反射触发
 */
public class TransTest1 {
    public static void main(String[] args)  {
        // 创建实例 传入构造方法参数 （函数名 参数类型 参数值）
        InvokerTransformer invokerTransformer = new InvokerTransformer(
                "exec",
                new Class[]{String.class},
                new String[]{"Calc.exe"}
        );

        try {
            // 通过反射机制依次获得Runtime类 getRuntime构造方法 最后生成Runtime实例
            // Object input = Class.forName("java.lang.Runtime").getMethod("getRuntime").invoke(Class.forName("java.lang.Runtime"));
            Object input = Runtime.getRuntime();
                    // 执行transform函数
            invokerTransformer.transform(input);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
