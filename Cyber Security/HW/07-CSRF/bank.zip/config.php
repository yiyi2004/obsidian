<?php
if ($_COOKIE['userid1'] == ""  || $_COOKIE['pass1'] == "")
{
	header("location:index.html");
}

?>