package com.msb.redis6.codeplus.codeplus.service;

import com.msb.redis6.codeplus.codeplus.util.TPoolimp;
import org.checkerframework.checker.units.qual.K;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.*;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * @author: 马士兵教育_周志垒
 * @create: 2022-02-20 16:11
 */
@Service
public class CacheService {


    @Autowired
    RedisTemplate<String,String> redisTemplate;

    @Autowired
    CacheManager cacheManager;

    @Autowired
    TPoolimp tp;

    public void resetData(Integer itemID, Integer num) {
        HashMap<String, Integer> keyAndVals = tp.getKeyAndVals(itemID, num);

        keyAndVals.forEach((k,v)-> redisTemplate.opsForValue().set(k,v+""));

    }

    public boolean decrNum(Integer itemID)   {

        /**
         * 通过减redis的num，如果小于0就不需要访问mysql
         *
         * 弊端：目前版本，redis没有任何的判断，全量的请求施加到redis
         * 除了商品数量的有效请求，其他都是无效请求
         * 如何提升性能呢？
         * redis是串行的，过滤性，你得去访问它，才知道是不是0，是不是负数
         * 可能一堆返回值都是负数
         * 必然会有无效请求
         * 第一个思路：尽量的减少无效
         *
         * 加逻辑，越早发现的，尽量的去规避后续的请求复杂度
         * 3，2，1，0，-1
         * 拦得住别人不去访问redis嘛？ 肯定是拦不住的
         * 能不能让请求进入redis返回快一些，或者让redis的操作精简一些
         *
         * 假设：
         *  先查后改。。。反而增加了负担
         *  如果返回负数，就改成0。。。超卖，无意义
         *
         *  有一个小思路：因为你做的是数值的计算，String类型的val
         *  encoding是int
         *  redis6.x的源码
         *
         *  通过二进制的操作
         *
         */


        try {
            ValueOperations<String, String> stringOps = redisTemplate.opsForValue();
            //这里是重点：
            /**
             * 再高并发下：
             * 一批10个串行到达redis，最后6个出现了负数
             * 这个6个会以O(4)的复杂度提交事务到redis
             * 这6个之后的进入redis的会有一个异常产生
             * 其实：前一个版本的访问量上多加了一个6个的事务访问量
             */
            Long decrement = stringOps.decrement(itemID.toString(), 1);
            if(decrement>=0){
                return true;
            }else{
                /**
                 * 数据的表示，编码：
                 * 9，8，7，6，5，4，3，2，1，0这样的数值是ascii
                 * X 0 0 0 0 0 0 0   X永远是0  0~127
                 * 如果我通过ops.setBit(itemID.toString(),0,true);
                 * 1 X X X X X X X  这个编码是错误的 按16进制给你返回，而且也不是int类型了
                 * 再操作decr 操作会报异常
                 *
                 * 多个操作放到一个事务里
                 *
                 * 不会死锁
                 * 但是会出现异常，执行失败
                 * 连接池的概念，有可能通过不同的连接发出
                 * 一个连接才是一个client，事务是基于client
                 *
                 * 通过异常的方式，可以规避多少重量的操作：
                 * 有的时候可能还需要很多的逻辑
                 */
                SessionCallback<Object> callback = new SessionCallback<Object>() {
                    @Override
                    public <K, V> Object execute(RedisOperations<K, V> operations) throws DataAccessException {
                        operations.multi();
                        ValueOperations ops = operations.opsForValue();
                        ops.set(itemID.toString(), "0");
                        ops.setBit(itemID.toString(), 0, true);
                        operations.exec();
                        return null;
                    }
                };

                redisTemplate.execute(callback);
                return false;
            }

        }catch(Exception e ){
            //System.out.println(e);
        }

        return false;


    }


    public boolean decrNumByThread(Integer itemID) {

        /**
         * tp  包含了一个map
         * 0 singleEs
         * 1 singleES
         *
         * 线程池需要callable
         * callable应该方式是 具体的itemid
         */

        String key = tp.getKey(itemID);

        Callable<Boolean> call = new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {

                try {
                    ValueOperations<String, String> stringOps = redisTemplate.opsForValue();
                    //这里是重点：
                    /**
                     * 再高并发下：
                     * 一批10个串行到达redis，最后6个出现了负数
                     * 这个6个会以O(4)的复杂度提交事务到redis
                     * 这6个之后的进入redis的会有一个异常产生
                     * 其实：前一个版本的访问量上多加了一个6个的事务访问量
                     */
                    Long decrement = stringOps.decrement(key, 1);
                    if(decrement>=0){
                        return true;
                    }else{
                        /**
                         * 数据的表示，编码：
                         * 9，8，7，6，5，4，3，2，1，0这样的数值是ascii
                         * X 0 0 0 0 0 0 0   X永远是0  0~127
                         * 如果我通过ops.setBit(itemID.toString(),0,true);
                         * 1 X X X X X X X  这个编码是错误的 按16进制给你返回，而且也不是int类型了
                         * 再操作decr 操作会报异常
                         *
                         * 多个操作放到一个事务里
                         *
                         * 不会死锁
                         * 但是会出现异常，执行失败
                         * 连接池的概念，有可能通过不同的连接发出
                         * 一个连接才是一个client，事务是基于client
                         *
                         * 通过异常的方式，可以规避多少重量的操作：
                         * 有的时候可能还需要很多的逻辑
                         */
                        SessionCallback<Object> callback = new SessionCallback<Object>() {
                            @Override
                            public <K, V> Object execute(RedisOperations<K, V> operations) throws DataAccessException {
                                operations.multi();
                                ValueOperations ops = operations.opsForValue();
                                ops.set(key, "0");
                                ops.setBit(key, 0, true);
                                operations.exec();
                                return null;
                            }
                        };

                        redisTemplate.execute(callback);
                        return false;
                    }

                }catch(Exception e ){
                    //System.out.println(e);
                }
                return false;
            }
        };
        /**
         * 如果这里用itemID，那么你分治的子key：itemID_0,itemID_1,又被分到一个singleES
         */
        Future<Boolean> resFuture = tp.routeToThread(key, call);
        /**
         * resFuture.addListener(ooxx) 观察者模式
         */

        Boolean aBoolean= false;
        try {
            aBoolean = resFuture.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }


        return aBoolean;
    }
}
