<?php

/**
 * Class UnSerializeTest
 * 反序列化演示
 */
class UnSerializeTest
{
  public $var = "hello wuya..";
  public function echoString(){
      echo $this->var;
  }

    public function __construct(){
        echo "__construct\n";
    }

    public function __destruct(){
        echo "__destruct\n";
    }

    public function __serialize(){
        echo "__serialize\n";
    }

    public function __unserialize(){
        echo "__unserialize\n";
    }

    public function __wakeup(){
        echo "__wakeup\n";
    }
}

// 创建一个新的类
//$obj1 = new UnSerializeTest();
// 调用该类的
//$obj1->echoString();

// 输出序列化以后的字符
//echo "序列化以后的结果：\n";
//echo serialize($obj1);

// 反序列化
// “O”表示对象，“15”表示对象名长度为15，“UnSerializeTest”为对象名，“1”表示有1个参数。
// “{}”里面是参数的key和value，“s”表示string对象，“11”表示长度，“var”则为key
// !注意，var内容和长度可以修改
$obj2 = unserialize('O:15:"UnSerializeTest":1:{s:3:"var";s:15:"hello wuyaziabc";}');

// 调用对象方法
//echo "反序列化以后执行的结果：\n";
var_dump($obj2);
$obj2->echoString();