package com.wuya.test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.parser.ParserConfig;

public class JsonTest {
    public static void main(String[] args) {
        // 从1.2.25开始，autotype默认关闭
        ParserConfig.getGlobalInstance().setAutoTypeSupport(true);
        // 序列化字符
        String serializedStr = "{\"@type\":\"com.wuya.test.User\",\"name\":\"wuya\",\"age\":66, \"flag\": true,\"sex\":\"boy\",\"address\":\"china\"}";//
        System.out.println("serializedStr=" + serializedStr);

        System.out.println("-----------------------------------------------\n\n");
        //通过parse方法进行反序列化，返回的是一个JSONObject]
        System.out.println("JSON.parse(serializedStr)：");
        Object obj1 =JSON.parse(serializedStr);
        System.out.println("parse反序列化对象名称:" + obj1.getClass().getName());
        System.out.println("parse反序列化：" + obj1);
        System.out.println("-----------------------------------------------\n");

        // 通过parseObject,不指定类，返回的是一个JSONObject
        System.out.println("JSON.parseObject(serializedStr)：");
        Object obj2 = JSON.parseObject(serializedStr);
        System.out.println("parseObject反序列化对象名称:" + obj2.getClass().getName());
        System.out.println("parseObject反序列化:" + obj2);
        System.out.println("-----------------------------------------------\n");

        // 通过parseObject,指定为object.class
        System.out.println("JSON.parseObject(serializedStr, Object.class)：");
        Object obj3 = JSON.parseObject(serializedStr, Object.class);
        System.out.println("parseObject反序列化对象名称:" + obj3.getClass().getName());
        System.out.println("parseObject反序列化:" + obj3);
        System.out.println("-----------------------------------------------\n");

        // 通过parseObject,指定为User.class
        System.out.println("JSON.parseObject(serializedStr, User.class)：");
        Object obj4 = JSON.parseObject(serializedStr, User.class);
        System.out.println("parseObject反序列化对象名称:" + obj4.getClass().getName());
        System.out.println("parseObject反序列化:" + obj4);
        System.out.println("-----------------------------------------------\n");
    }

}
