<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Home</title>
</head>
<body>

<h1>这是你第1234次访问本网站</h1>
<p></p>
<p>欢迎下次再来</p>
<?php include 'footer.php';?>

</body>
</html>