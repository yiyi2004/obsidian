package com.wuya;

import java.lang.Runtime;
import java.lang.Process;

public class WinCalc {
    public WinCalc() {
        try{
            // 要执行的命令
            String commands = "calc.exe";
            Process pc = Runtime.getRuntime().exec(commands);
            pc.waitFor();
        } catch(Exception e){
            e.printStackTrace();
        }

    }

    public static void main(String[] argv) {
        WinCalc e = new WinCalc();
    }

}