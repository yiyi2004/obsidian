<head><meta charset=utf-8>
	<title>xxe测试</title>
</head>
<body>
	<form action='' method='post'>xml数据:<br>
		<textarea type="text" name="data"></textarea>
		<br><input type='submit' value='提交' name='sub'>
	</form>
</body>

<?php
  date_default_timezone_set("PRC");
  if(!empty($_POST['sub'])){ 
  	$data= $_POST['data'];
    $xml = simplexml_load_string($data);
    print($xml); 
  }
?>