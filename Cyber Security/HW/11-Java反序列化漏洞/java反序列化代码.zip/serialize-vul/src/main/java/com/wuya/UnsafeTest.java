package com.wuya;

import java.io.*;

public class UnsafeTest {
    public static void main(String args[]) throws Exception {
        UnsafeClass Unsafe = new UnsafeClass();
        Unsafe.name = "hacked by wuya";
        // 序列化
        FileOutputStream fos = new FileOutputStream("D:/wuya.yyy");
        ObjectOutputStream os = new ObjectOutputStream(fos);
        os.writeObject(Unsafe);
        os.close();

        //从 反序列化
        FileInputStream fis = new FileInputStream("D:/wuya.yyy");
        ObjectInputStream ois = new ObjectInputStream(fis);
        UnsafeClass objectFromDisk = (UnsafeClass) ois.readObject();
        System.out.println(objectFromDisk.name);
        ois.close();
    }
}
