<?php
	try{
		$dsn = "mysql:host=localhost;dbname=bank";
		$db = new PDO($dsn,"root","123456",array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
	}catch(PDOException $e){
        die("Error!: " . $e->getMessage() . "<br/>");
    }
?>