package com.msb.redis6.codeplus.codeplus.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.core.ValueOperations;

import java.util.HashMap;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author: 马士兵教育_周志垒
 */
public class TPoolimp {

    ConcurrentHashMap<Integer, ExecutorService> map = new ConcurrentHashMap<>();
    private Integer num;
    private Integer divide;

    private AtomicInteger divideIncr = new AtomicInteger();
    private AtomicInteger tempInt = new AtomicInteger();


    TPoolimp(Integer numTp, Integer divideNum) {
        num = numTp;
        this.divide = divideNum;
        initMap();
    }

    TPoolimp(Integer numTp) {
        this(numTp, 0);
    }

    private void initMap() {
        for (int i = 0; i < this.num; i++) {
            map.put(i, Executors.newSingleThreadExecutor());
        }
    }


    public HashMap<String, Integer> getKeyAndVals(Integer itemID, Integer num) {
        HashMap<String, Integer> map = new HashMap<>();
        if (this.divide > 0) {
            for (int i = 0; i < this.divide; i++) {
                map.put(itemID + "_" + i, num / this.divide);
            }
        } else {
            map.put(itemID.toString(), num);
        }
        return map;
    }

    public String getKey(Integer itemID) {
        if (this.divide > 0) {
            /**
             * 对于怎么控制子key的获得，有很多的“策略”
             */
            return itemID + "_" + tempInt.incrementAndGet() % this.divide;
            /**
             * itemID_0
             * itemID_1
             */
        }
        return itemID.toString();
    }


    public Future<Boolean> routeToThread(String key,Callable<Boolean> call) {

        int index = key.hashCode() % num;
//        int index = itemID % num;
        ExecutorService executorService = map.get(index);
        return executorService.submit(call);
    }
}
