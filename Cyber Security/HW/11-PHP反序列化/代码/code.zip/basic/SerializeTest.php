<?php

/**
 * Class SerializeTest
 * 序列化演示
 */
class SerializeTest
{
  public $var = "hello wuya\n";
  public function echoString(){
      echo $this->var;
  }

    public function __construct(){
        echo "__construct\n";
    }

    public function __destruct(){
        echo "__destruct\n";
    }

    public function __toString(){
        return "__toString\n";
    }
}

// 创建一个新的类
$obj = new SerializeTest();
// 调用该类的方法
$obj->echoString();
// 输出序列化以后的字符
echo serialize($obj)."\n";