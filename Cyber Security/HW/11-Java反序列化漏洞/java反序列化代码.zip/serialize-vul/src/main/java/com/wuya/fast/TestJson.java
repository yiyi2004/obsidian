package com.wuya.fast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wuya.Person;

public class TestJson {
    public static void main(String[] args) {
        test1();
        test2();

    }

    public static void test1(){
        Person person = new Person("fast",999);
        JSONObject json = (JSONObject) JSON.toJSON(person);
        System.out.println(json);
        System.out.println(json.get("name"));
        System.out.println(json.get("age"));
    }

    public static void test2(){
        String s ="{\"name\":\"fast\",\"age\":999}";
        JSONObject json1 = JSON.parseObject(s);
        System.out.println(json1);

        Person real = JSON.parseObject(s, Person.class);
        System.out.println(real);
        System.out.println(real.name);
        System.out.println(real.age);
    }

}
