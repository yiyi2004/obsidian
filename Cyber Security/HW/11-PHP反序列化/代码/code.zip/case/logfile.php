<?php
/**
 * Class logfile
 * 功能说明：临时记录日志到error.log文件
 * __destruct被调用的时候，删除 error.log 文件
 */
class logfile
{
    //log文件名
    public $filename = 'error.log';
    //一些用于储存日志的代码
    public function logdata($text)
    {
        echo 'log data:'.$text.'<br />';
        file_put_contents($this->filename,$text,FILE_APPEND);
    }

    //destrcuctor 删除日志文件
    public function __destruct()
    {
        echo '__destruct deletes '.$this->filename.' file.<br />';
        unlink(dirname(__FILE__).'/'.$this->filename);
    }
}
?>