package com.msb.redis6.codeplus.codeplus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeplusApplicationTests {

    @Test
    void contextLoads() {
    }

}
