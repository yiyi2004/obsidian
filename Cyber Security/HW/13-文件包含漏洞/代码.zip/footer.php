<?php
echo "<p>copyright © 2021-" . date("Y") . " wuya </p>";
?>