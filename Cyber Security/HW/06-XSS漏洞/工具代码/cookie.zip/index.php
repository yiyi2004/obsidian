<?php 
 header("Content-Type:text/html;charset=utf-8"); 
 session_start(); 
 // session中有这个用户名，代表已经登录
 if(isset($_SESSION['username'])) 
 { 
  echo $_SESSION['username'].":你好，欢迎进入个人中心！<br/>"; 
  echo "<a href='logout.php'>注销</a>"; 
 } else { 
  // 没有这个用户名的session值
  echo "你还未登录，请<a href='login.html'>登录</a>"; 
 } 
?> 