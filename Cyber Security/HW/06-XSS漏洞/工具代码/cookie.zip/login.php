<?php 
 header("Content-Type:text/html;charset=utf-8"); 
 // 开启会话，产生sessionid
 session_start(); 
 if(isset($_POST['login'])) 
 { 
  $username = trim($_POST['username']); 
  $password = trim($_POST['password']); 
  if(($username=='')||($password=='')) 
  { 
   header('refresh:3;url=login.html'); 
   echo "用户名或密码不能为空，3秒后跳转到登录页面"; 
   exit; 
  } 
  // 用户名和密码没有查表，直接写死
  else if(($username!='admin')||($password!='123456')) 
  { 
   //用户名或密码错误 
   header('refresh:3;url=login.html'); 
   echo "用户名或密码错误，3秒后跳转到登录页面"; 
   exit; 
  } 
  // 没有查表，直接写死
  else if(($username=='admin')&&($password=='123456')) 
  { 
   //登录成功将信息保存到session中 
   $_SESSION['username']=$username; 
   $_SESSION['islogin']=1; 
   //如果勾选7天内自动保存，则将其保存到cookie 
   if($_POST['remember']=="yes") 
   { 
    setcookie("admin",$username,time()+7*24*60*60); 
    setcookie("code",md5($username.md5($password)),time()+7*24*60*60); 
   } 
   else 
   { 
    setcookie("admin",'',time()-1); 
    setcookie("code",'',time()-1); 
   } 
   //跳转到用户首页 
   header('refresh:3;url=index.php'); 
  } 
 } 
?>