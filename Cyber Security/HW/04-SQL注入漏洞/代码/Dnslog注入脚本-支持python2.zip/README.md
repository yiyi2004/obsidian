# DnslogSqlinj

## DnsLog Sql Injection Tool with ceye.io

## Usage

```
Usage: dnslogSql.py [options] -u http://10.1.1.9/sqli-labs/Less-9/?id=1' and ({})--+

Options:
  --version             show program's version number and exit
  -h, --help            show this help message and exit
  -n TASKNAME, --name=TASKNAME
                        task name
  -t THREAD_COUNT, --thread=THREAD_COUNT
                        thread_count
  -u URL, --url=URL     target include injection
  -i INF, --inf=INF     Testing target and Try to get information
  --dbs                 get database
  -D DB                 database name
  --tables              get table
  -T TABLE              table name
  --columns             get column
  -C COLUMN             column name
  --dump                get data
  ```
  
  ## Editor
  
  ```Editor config.py APItoken and DNSurl with yours!```
