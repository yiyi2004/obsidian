<?php
  //获取提交的表单值
  $user=$_POST["user"];
  $password=$_POST["password"];
  echo "user:".$user;
  echo "<br/>password:".$password."<br/>";

  //连接数据库
  $con = mysqli_connect("localhost","root","123456", "wuya");
  if (!$con)
  {
    die('Could not connect database: ' . mysqli_error());
  }

  //插入数据表
  $sql = "insert into xss(user,password) values('{$user}','{$password}');";
  // echo $sql;
  if (mysqli_query($con, $sql)) {
      echo "<meta http-equiv='Content-Type'' content='text/html; charset=utf-8'>";
      echo "注册成功";
  } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
   
  mysqli_close($con);
?>