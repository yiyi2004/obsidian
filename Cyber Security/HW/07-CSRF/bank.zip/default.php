<?php
//session_start(); 
//session_set_cookie_params(15*15*60);
//session_cache_expire(3*60);
include("config.php");
?>
<html>
<head>
	<title>
		主页面
	</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<style type="text/css">
	*{ margin:0; padding:0;}
	
	body{
		text-align:center;
	}
</style>
	<script language="javascript">
		function tiao()
		{
			location.href="logout.php";
		}
	</script>
</head>
<body style="width:500px;align:center">
	<h1>欢迎
	<?php 
		echo $_COOKIE['views'];
		
		include("conn/conn.php");
		$sql = $db->query("select * from account where username='".$_COOKIE['views']."'");
		$sqlres = $sql->fetch();
	?>
	</h1>
	<label>账户余额:&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $sqlres['balance'];?> 人民币</label>
	
	<form action="transfer.php" method="GET" name="yonghu">
		<label>请输入对方账号:</label>&nbsp;&nbsp;
		<input value="" type="text" name="nameid"></input>
		<br />
		<label>请输入转账金额:</label>&nbsp;&nbsp;
		<input value="" type="text" name="balance"></input>
		<br />
		
		 <input name="imageField" type="image" src="default_06.gif" width="74" height="24" border="0">
		 <br />
	</form>
	
	<input name="imageField" type="image" src="default_05.gif" width="74" height="24" border="0" onclick="tiao()">
		 <br />
	
</body>
</html>