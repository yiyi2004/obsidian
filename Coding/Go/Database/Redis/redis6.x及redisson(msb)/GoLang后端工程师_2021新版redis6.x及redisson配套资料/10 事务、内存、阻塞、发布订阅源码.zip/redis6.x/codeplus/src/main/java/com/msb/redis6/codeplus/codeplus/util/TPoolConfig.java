package com.msb.redis6.codeplus.codeplus.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author: 马士兵教育_周志垒
 */
@Configuration
public class TPoolConfig {

    @Value("${server.itemmeta.nums}")
    Integer nums;

    @Value("${server.itemmeta.divide}")
    Integer divideNum;

    @Bean
    TPoolimp getTPoolimp() {
        TPoolimp tp = new TPoolimp(nums, divideNum);
        return tp;
    }
}
