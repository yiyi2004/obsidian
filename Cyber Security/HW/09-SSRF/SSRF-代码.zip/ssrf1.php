<?php
function curl($url){  
    $ch = curl_init();
    // 设置URL和相应的选项
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HEADER, 0); // 启用时会将头文件的信息作为数据流输出  
    // 抓取URL并把它传递给浏览器  
    curl_exec($ch);
    //关闭cURL资源，并且释放系统资源  
    curl_close($ch);
}

$url = $_GET['url'];
curl($url);  
?>