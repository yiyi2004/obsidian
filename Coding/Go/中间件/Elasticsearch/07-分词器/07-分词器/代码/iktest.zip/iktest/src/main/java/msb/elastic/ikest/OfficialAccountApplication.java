package msb.elastic.ikest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OfficialAccountApplication {

    public static void main(String[] args) {
        SpringApplication.run(OfficialAccountApplication.class, args);
    }

}
