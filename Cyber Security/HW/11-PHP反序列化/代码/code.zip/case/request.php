<?php
/**
 * 引用了 logfile文件，包含__destruct方法
 *
 */
include 'logfile.php';
class User
{
    //类数据
    public $age = 0;
    public $name = '';
    //输出数据
    public function printdata()
    {
        echo 'User '.$this->name.' is'.$this->age.' years old.<br />';
    }
}
// 通过GET请求参数传入字符
// 此处可以反序列化任意对象
$usr = unserialize($_GET['param']);
?>