<?php
  $id = $_GET['id'];

  // 连接数据库
  $con = mysqli_connect("localhost","root","123456", "wuya");

  // 查询数据
  $sql = "select * from xss where id={$id};";
  // echo $sql;
  $result = mysqli_query($con, $sql);

  while($row = mysqli_fetch_assoc($result)) {
    echo $row['user'];
  }
?>