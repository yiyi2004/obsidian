<?php
/**
 * Class User
 * 演示序列化中不需要序列化的字段
 */
class User{
    const SITE = 'wuya';

    public $username;
    public $nickname;
    private $password;

    public function __construct($username, $nickname, $password)
    {
        $this->username = $username;
        $this->nickname = $nickname;
        $this->password = $password;
    }

    // 重载序列化调用的方法
    public function __sleep()
    {
        // 返回需要序列化的变量名，过滤掉password变量
        return array('username', 'nickname');
    }
}
$user = new User('hackerwuya', 'wuya', '123456');
var_dump(serialize($user));
